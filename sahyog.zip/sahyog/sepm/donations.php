<?php ob_start();
  $page_title = 'Donation Page';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(1);
?>

<?php include_once('layouts/header.php'); ?>

<div>
    <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>League Links</h2>

<table>
  <tr>
    <th>Leagues</th>
    <th>League URL</th>
  </tr>
  <tr>
    <td>IPL</td>
    <td><a href="https://www.iplt20.com/news/197813/vivo-ipl-2020-player-contract-extensions-announced">https://www.iplt20.com/news/197813/vivo-ipl-2020-player-contract-extensions-announced</a></td>
  </tr>
  <tr>
    <td>Big Bash</td>
    <td><a href="https://www.bigbash.com.au/fixtures">https://www.bigbash.com.au/fixtures</a></td>
  </tr>
  <tr>
    <td>English County League</td>
    <td><a href="https://www.ecb.co.uk/news/county">https://www.ecb.co.uk/news/county</a></td>
  </tr>
  
</table>

</div>
  



<?php include_once('layouts/footer.php'); ?>
